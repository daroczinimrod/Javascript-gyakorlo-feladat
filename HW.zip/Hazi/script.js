
function szerkeztheto() {
    Befogo1 = document.getElementById("befogo1").value;
    Befogo2 = document.getElementById("befogo2").value;
    atfogo = document.getElementById("atfogo").value;

}

function veletlen() {

}

function aSzamitas() {

}